(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var BUZZ;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['brentjanderson:buzz'] = {
  BUZZ: BUZZ
};

})();

//# sourceMappingURL=brentjanderson_buzz.js.map
